package polynomial;

import java.util.Objects;

/**
 * This class represents each term in the polynomial.
 */
public class Term {
  private int coefficient;
  private int power;
  private String term;

  /**
   * constructor to create term and extract the coefficient and power of the term.
   *
   * @param term is a string representing each term of the equation
   */
  public Term(String term) {
    this.term = term;
    extractCoefficientFromTerm(term);
    extractPowerFromTerm(term);
    addSign();

  }

  /**
   * term constructor for creating the term with given parameters.
   * @param coefficient is the coefficient of the term.
   * @param power is the power of the term.
   * @param term is the string representation of the term.
   */

  public Term(int coefficient, int power, String term) {
    this.coefficient = coefficient;
    this.power = power;
    this.term = term;
    addSign();
  }

  private void extractPowerFromTerm(String term) {
    int powerIndex;
    // if the term contains the x then get the coefficient
    if (term.contains("x")) {
      powerIndex = term.indexOf("^");
      power = Integer.parseInt(term.substring(powerIndex + 1));
      // power is negative
      if (power < 0) {
        throw new IllegalArgumentException("Power must be non negative");
      }
    }
  }


  // to get the coefficient of the term
  private void extractCoefficientFromTerm(String term) {
    int coefficientIndex = 0;
    coefficientIndex = term.indexOf("x") > -1 ? term.indexOf("x") : term.indexOf("x");
    if (coefficientIndex > 0 && term.charAt(0) != '+' && term.charAt(0) != '-') {
      coefficient = Integer.parseInt(term.substring(0, coefficientIndex));
    } else if (coefficientIndex == 0) {
      //means there is no digit in the term
      coefficient = 1;
    } else {
      coefficient = coefficientIndex > -1 ? term.substring(1, coefficientIndex).equals("")
              ? 1 : Integer.parseInt(term.substring(0, coefficientIndex)) : Integer.parseInt(term);
    }
    if (coefficient == 0) {
      this.term = "";
      return;
    }
  }

  /**
   * method to get the coefficient of a current term.
   * @return the coefficient of the current term.
   */
  public int getCoefficient() {
    return this.coefficient;
  }

  /**
   * method to return the power of the current term.
   *
   * @return the power for the given term.
   */
  public int getPower() {
    return this.power;
  }

  /**
   * to compare the terms.
   * @param term used for comparing with the current term.
   * @return true or false.
   */
  public boolean lesserThan(Term term) {
    return term.getPower() < this.getPower();
  }

  /**
   * method to perform addition on the current term with the given term.
   * @param term used to add to the current term.
   * @return the sum of the two terms.
   */
  public Term add(Term term) {
    this.coefficient += term.getCoefficient();
    addSign();
    updateExistingTerm();
    return this;
  }

  /**
   * method to perform multiplication on current term with the given term.
   * @param term to be multiplied with the current term.
   * @return the product of the two terms.
   */
  public Term multiply(Term term) {
    this.coefficient *= term.getCoefficient();
    this.power += term.getPower();
    addSign();
    updateExistingTerm();
    return this;
  }

  // helper class to update the term after changing the power of the term
  private void updateExistingTerm() {
    String pow = this.coefficient != 0 ? "x^" + String.valueOf(this.power) : "";
    this.term = String.valueOf(this.coefficient) + pow;
  }

  /**
   * to keep track of the signs of the terms after various operations on the terms.
   */
  public void addSign() {
    if ( !this.term.equals("") && this.term.charAt(0) != '+' && this.term.charAt(0) != '-' ) {
      String prefix = (coefficient > 0) ? "+" : "";
      this.term = prefix + this.term;
    }
  }

  /**
   * method to perform first derivation on the current term.
   *
   * @return the derivative of the current term.
   */
  public Term deriveTerm() {
    int pow = this.power - 1;
    if (pow > 0) {
      this.coefficient = this.coefficient * this.getPower();
      this.power = this.power - 1;
      updateExistingTerm();
    } else if (pow < 0) {
      this.coefficient = 0;
      this.power = 0;
      this.term = "";
    } else {
      this.power = this.power - 1;
      this.term = String.valueOf(this.coefficient);
      addSign();
    }
    return this;
  }

  /**
   * method overriding the equals method.
   */
  @Override
  public boolean equals(Object term) {
    if (term.getClass() != this.getClass()) {
      return false;
    }
    return this.coefficient == ((Term) term).coefficient
            && this.power == ((Term) term).power;
  }

  @Override
  public int hashCode() {
    return Objects.hash(coefficient, power, term);
  }

  /**
   * method to override the default toString method.
   *
   * @return the term in string format.
   */
  @Override
  public String toString() {
    if (term.equals("0")) {
      return "";
    }
    return term;
  }


}
