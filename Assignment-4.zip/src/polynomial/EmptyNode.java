package polynomial;

/**
 * class that represents the empty node or terminal node of a list. in this case, it marks the end
 * of the polynomial equation.
 */
public class EmptyNode implements IListOfTerms {

  /**
   * method to perform insertion in the beginning of the list.
   *
   * @param term represents the first term of the equation.
   * @return the equation consisting of one term only.
   */
  @Override
  public IListOfTerms insert(Term term) {
    if (term.toString().length() > 0 && term.toString().charAt(0) != '+'
            && term.toString().charAt(0) != '-') {
      term.addSign();
    }
    return new ElementNode(term, this);
  }

  /**
   * method to perform multiplication on the empty equation.
   *
   * @param term which is multiplied to the list of terms in the equation.
   * @return empty node as there is no equation to multiply with.
   */
  @Override
  public IListOfTerms multiply(Term term) {
    return this;
  }

  /**
   * method to perform evaluation on the equation.
   *
   * @param val used to evaluate the equation.
   * @return zero since there is no polynomial to compute with the given value.
   */
  @Override
  public double evaluateTerm(double val) {
    return 0;
  }

  /**
   * method to perform sorting based on ascending order of the degree of each term in the equation
   * list.
   *
   * @return the sorted equation based on degree.
   */
  @Override
  public IListOfTerms sort() {
    return new EmptyNode();
  }

  /**
   * method to perform first derivation on an empty polynomial, in this case.
   *
   * @return the derived equation.
   */
  @Override
  public IListOfTerms derivative() {
    return this;
  }

  /**
   * method to override the default toString method.
   *
   * @return the string format for the empty polynomial.
   */
  @Override
  public String toString() {
    return "";
  }

  @Override
  public boolean equals(Object o) {
    return (o instanceof EmptyNode);
  }

  @Override
  public int hashCode() {
    return super.hashCode();
  }
}
