package polynomial;

/**
 * Represents the abstract list format for the terms of the polynomial equation.
 */
public interface IListOfTerms {

  /**
   * method to perform insertion of terms in the equation.
   *
   * @param term that is inserted in the polynomial equation.
   * @return the equation after inserting the term in the equation.
   */
  IListOfTerms insert(Term term);

  /**
   * method to perform the multiplication on the list with the given term.
   *
   * @param term is each term in the equation.
   * @return the product after multiplying each term of the list with the given list.
   */
  IListOfTerms multiply(Term term);

  /**
   * method to perform evaluation of a given polynomial equation.
   *
   * @param val is the value to be taken for evaluating the entire equation.
   * @return a double value after evaluating the equation.
   */
  double evaluateTerm(double val);

  /**
   * method to perform the sorting of equation based on the power of the terms in ascending order.
   *
   * @return the sorted equation based on the degree or power of each term.
   */
  IListOfTerms sort();

  /**
   * method to perform first derivation on the equation.
   *
   * @return the equation after deriving each term.
   */
  IListOfTerms derivative();
}
