package polynomial;

import java.util.Objects;

/**
 * Implementation of the node having the term data and link to the rest of the list.
 */
public class ElementNode implements IListOfTerms {


  private Term term;
  private IListOfTerms rest;

  /**
   * constructor to create a single node for the list.
   * @param term represents each of the terms in the equation.
   * @param rest represents the rest of the terms in the list.
   */
  public ElementNode(Term term, IListOfTerms rest) {
    this.term = term;
    this.rest = rest;
  }

  /**
   * inserts a new term to an existing list of element nodes.
   * @param term is the term that is added to the equation.
   * @return the list after adding the term.
   */
  public IListOfTerms insert(Term term) {
    if (this.term != null && this.term.lesserThan(term)) {
      term.addSign();
      return new ElementNode(this.term, this.rest.insert(term));
    } else if ( this.term != null && this.term.getPower() == term.getPower()) {
      this.term.add(term);
      this.term.addSign();
      return this;
    } else {
      term.addSign();
      return new ElementNode(term, this);
    }
  }

  /**
   * method to perform the multiplication on the list with the given term.
   * @param term is each term in the equation.
   * @return the product after multiplying each term of the list with the given list.
   */
  @Override
  public IListOfTerms multiply(Term term) {
    this.term.multiply(term);
    this.term.addSign();
    return this.rest.multiply(term);
  }

  /**
   * method to perform evaluation of a given polynomial equation.
   * @param val is the value to be taken for evaluating the entire equation.
   * @return a double value after evaluating the equation.
   */
  @Override
  public double evaluateTerm(double val) {
    return ((this.term.getCoefficient() * (Math.pow(val, this.term.getPower()))) + this.rest
            .evaluateTerm(val));
  }

  /**
   * method to perform the sorting of equation based on the power of the terms in ascending order.
   * @return the sorted equation based on the degree or power of each term.
   */
  @Override
  public IListOfTerms sort() {
    return this.rest.sort().insert(this.term);
  }

  /**
   * method overriding the equal method.
   */
  @Override
  public boolean equals(Object o) {
    boolean result = false;
    if (o != null) {
      if (this.term.equals(((ElementNode) o).term)) {
        result = this.rest.equals(((ElementNode) o).rest);
      }
    }
    return result;
  }

  @Override
  public int hashCode() {
    return Objects.hash(term, rest);
  }

  /**
   * method to perform first derivation on the equation.
   * @return the equation after deriving each term.
   */
  @Override
  public IListOfTerms derivative() {
    return new ElementNode(this.term.deriveTerm(), this.rest.derivative());
  }

  /**
   * overriding the default toString method.
   * @return the equation as a string.
   */
  @Override
  public String toString() {
    return this.term.toString() + this.rest.toString();
  }

}
