package polynomial;

/**
 * Defines all the methods and operations for the polynomial.
 */
public interface Polynomial {

  /**
   * It takes the coefficient and power to add a term to the existing polynomial.
   * @param coefficient is an integer.
   * @param power       to which the term is raised. It is a whole number.
   * @throws IllegalArgumentException is thrown when term is invalid.
   */
  void addTerm(int coefficient, int power) throws IllegalArgumentException;

  /**
   * method to get the degree of the current equation.
   * @return the highest degree of the polynomial.
   */
  int getDegree();

  /**
   * method to get the coefficient for the given power in the current equation.
   * @param power to get the coefficient of the term corresponding to that power.
   * @return the coefficient to that power.
   */
  int getCoefficient(int power);

  /**
   * method to perform evaluation of the equation with the given value.
   * @param arg is a double-precision decimal number.
   * @return returns a double-precision result by evaluating the polynomial.
   */
  double evaluate(double arg);

  /**
   * method does not mutate either polynomials.
   * @param eqn is another polynomial object.
   * @return the new polynomial by adding the two polynomials.
   */
  Polynomial add(Polynomial eqn);

  /**
   * method does not mutate either polynomials.
   * @param eqn is another polynomial object.
   * @return the new polynomial obtained by multiplying the two polynomials.
   */
  Polynomial multiply(Polynomial eqn);

  /**
   * gives the first derivative of the current equation.
   * @return the first derivative of the polynomial.
   */
  Polynomial derivative();

}
