package polynomial;

import java.util.Objects;
import java.util.Scanner;


/**
 * Implementation class for the Polynomial equation operations.
 */
public class PolynomialImpl implements Polynomial {

  // holds the head pointer to the list.
  private IListOfTerms startNode;

  public PolynomialImpl() {
    startNode = createEqn(new Scanner(""));
  }

  /**
   * constructor to create a new polynomial.
   * @param polynomialEqn with each term separated by space.
   */
  public PolynomialImpl(String polynomialEqn) {
    if (polynomialEqn == null) {
      throw new IllegalArgumentException("String is not valid");
    }
    startNode = createEqn(new Scanner(polynomialEqn));
  }


  // helper method to create all the element nodes of the equation consisting of the terms.
  private IListOfTerms createEqn(Scanner scanner) throws IllegalArgumentException {
    try {
      if (scanner.hasNext()) {
        String t = scanner.next();
        Term term = new Term(t);
        return new ElementNode(term, createEqn(scanner)).sort();
      }
      return new EmptyNode();
    } catch (Exception e) {
      throw new IllegalArgumentException(e.getMessage());
    }
  }

  /**
   * method to add a new term to the current equation.
   * @param coefficient is an integer.
   * @param power       to which the term is raised. It is a whole number.
   * @throws IllegalArgumentException thrown when the power is less than zero.
   */
  @Override
  public void addTerm(int coefficient, int power) throws IllegalArgumentException {
    if (coefficient == 0) {
      return;
    }
    else  if (power < 0) {
      throw new IllegalArgumentException("power must be non negative");
    }

    String t = String.valueOf((coefficient));
    t = t +  (power > 0 ? ("x^" + power) : "");
    Term newTerm = new Term(coefficient,power,t);
    startNode = startNode.insert(newTerm);

  }

  /**
   * method to find the highest degree of the current equatin.
   * @return the degree of the equation.
   */
  @Override
  public int getDegree() {
    String eqn = this.startNode.toString();
    if (eqn.equals("")) {
      return 0;
    }
    int powerIndex = eqn.indexOf("^");
    return Integer.parseInt(String.valueOf(eqn.charAt(powerIndex + 1)));
  }

  /**
   * method to extract the coefficient of the term with the given power.
   * it returns zero if no such coefficient exists.
   * @param power to get the coefficient of the term corresponding to that power.
   * @return the coefficient for the given power.
   */
  @Override
  public int getCoefficient(int power) {
    int endIndex;
    if (power < 0) {
      throw new IllegalArgumentException("No term with negative power is present");
    }
    String[] eqn = this.toString().split("(?=\\+|(?=-))");

    // handle last term
    String lastTerm = eqn[eqn.length - 1];
    if (!lastTerm.contains("x^")) {
      eqn[eqn.length - 1] = eqn[eqn.length - 1] + ("x^0");
    }
    int result = 0;
    for (String s : eqn) {
      endIndex = s.indexOf("x^" + power);
      // if the endIndex is present,i.e the term with the given power is present.
      if (endIndex > 0) {
        result = Integer.parseInt(s.substring(0, endIndex));
        break;
      }
    }
    return result;
  }

  /**
   * method to perform evaluation of a given equation by passing the double value.
   * @param arg is a double-precision decimal number.
   * @return the evaluated equation.
   */
  @Override
  public double evaluate(double arg) {
    return this.startNode.evaluateTerm(arg);
  }

  /**
   * method to perform addition of another equation to a given equation.
   * @param eqn is another polynomial object.
   * @return the sum of both the equations.
   */
  @Override
  public Polynomial add(Polynomial eqn) {
    Polynomial sum = new PolynomialImpl();
    if (this.toString().equals("0")) {
      getSum(sum, eqn);
    } else {
      getSum(sum, this);
      getSum(sum, eqn);
    }
    return sum;

  }

  // helper method to get the sum of the polynomials.
  private Polynomial getSum(Polynomial sum, Polynomial eqn) {
    String delimiters = "(?=\\+|(?=-))";
    for (String s : eqn.toString().split(delimiters)) {
      Term t = new Term(s);
      sum.addTerm(t.getCoefficient(), t.getPower());
    }
    return sum;
  }

  /**
   * method to perform multiplication of two polynomials.
   * @param eqn is another polynomial object.
   * @return the product of the two polynomials.
   */
  @Override
  public Polynomial multiply(Polynomial eqn) {
    if (this.toString().equals("0")) {
      return new PolynomialImpl();
    }
    String delimiters = "(?=\\+|(?=-))";
    String original = this.toString().replaceAll(delimiters, " ");
    IListOfTerms startIndex = createEqn(new Scanner(original));

    for (String s : eqn.toString().split(delimiters)) {
      Term t = new Term(s);
      startIndex.multiply(t);
    }

    String p = startIndex.toString().replaceAll(delimiters, " ");
    return new PolynomialImpl(p);
  }


  /**
   * method to perform first derivation on the polynomial equation.
   * @return the first derivation of the polynomial object.
   */
  @Override
  public Polynomial derivative() {
    Polynomial p = this;
    this.startNode.derivative();
    return p;
  }

  /**
   * method overriding the default toString method.
   * @return the polynomial equation.
   */
  @Override
  public String toString() {
    int len = this.startNode.toString().length();
    String eqn = (len > 0) && (this.startNode.toString().charAt(0)) == '+'
            ? this.startNode.toString().replaceFirst("\\+", "") : this.startNode.toString();
    eqn = eqn.replace("x^0", "");
    return (len < 1) ? "0" : eqn;
  }


  /**
   * method overriding the default equals method.
   * @param o another polynomial equation.
   * @return true if both equations are same.
   */
  @Override
  public boolean equals(Object o) {
    PolynomialImpl that = (PolynomialImpl) o;
    return this.startNode.equals(that.startNode);
  }

  /**
   * method overriding the default hashcode value.
   * @return the hashcode for the polynomial object.
   */
  @Override
  public int hashCode() {
    return Objects.hash(startNode);
  }
}
