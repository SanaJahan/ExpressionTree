import org.junit.Test;

import polynomial.Polynomial;
import polynomial.PolynomialImpl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Unit tests for the Polynomial Implementation class.
 */
public class PolynomialImplTest {

  private Polynomial polynomial;
  private Polynomial emptyPolynomial;

  /**
   * test for toString on empty polynomial.
   */
  @Test(expected = IllegalArgumentException.class)
  public void shouldReturnZeroForEmptyPolynomial() {
    emptyPolynomial = new PolynomialImpl();

    assertEquals("0", emptyPolynomial.toString());

    // should throw illegal argument exception
    emptyPolynomial = new PolynomialImpl(null);
  }

  /**
   * Should return the non empty polynomial in String format.
   */
  @Test
  public void shouldReturnStringForNonEmptyPolynomial() {
    polynomial = new PolynomialImpl("4x^3 +3x^1 -5");
    assertEquals("4x^3+3x^1-5", polynomial.toString());

    polynomial = new PolynomialImpl("102");
    assertEquals("102", polynomial.toString());

    polynomial = new PolynomialImpl("+3x^4 -2x^5 -5 +11x^1");
    assertEquals("-2x^5+3x^4+11x^1-5", polynomial.toString());

    polynomial = new PolynomialImpl("1890x^188");
    Polynomial polynomial2 = new PolynomialImpl("3x^188 -2x^188 -5 +11x^1");
    Polynomial sum = polynomial2.add(polynomial);
    assertEquals("1891x^188+11x^1-5", sum.toString());
  }

  /**
   * Should throw error for equation having negative power.
   */
  @Test(expected = IllegalArgumentException.class)
  public void shouldThrowIllegalArgException() {
    polynomial = new PolynomialImpl("+3x^-4 -2x^5 -5 +11x^1");
  }

  /**
   * For a negative power, the add term method throws an IllegalArgumentException.
   */
  @Test(expected = IllegalArgumentException.class)
  public void shouldThrowExceptionForNegativePower() {
    polynomial = new PolynomialImpl("4x^3 +3x^1 -5");
    int coefficient = 2;
    int power = -2;

    polynomial.addTerm(coefficient, power);
  }

  /**
   * This test adds a new tern to the existing polynomial.
   */
  @Test
  public void shouldAddTermToExistingPolynomial() {
    polynomial = new PolynomialImpl("4x^3 +3x^1 -5");
    int coefficient = 3;
    int power = 3;

    polynomial.addTerm(coefficient, power);

    String expectedOutput = "7x^3+3x^1-5";

    assertEquals(expectedOutput, polynomial.toString());

    polynomial.addTerm(coefficient, 2);
    assertEquals("7x^3+3x^2+3x^1-5", polynomial.toString());

  }

  /**
   * Insert term to an empty polynomial.
   */
  @Test
  public void shouldAddTermToAnEmptyPolynomial() {
    int coefficient = 3;
    int power = 3;
    emptyPolynomial = new PolynomialImpl();

    emptyPolynomial.addTerm(coefficient, power);
    assertEquals("3x^3", emptyPolynomial.toString());

    emptyPolynomial.addTerm(-102, 0);
    assertEquals("3x^3-102", emptyPolynomial.toString());

    emptyPolynomial.addTerm(-2, 0);
    emptyPolynomial.addTerm(-2, 0);
    assertEquals("3x^3-106", emptyPolynomial.toString());
  }

  /**
   * test for getting degree as 0 for an empty polynomial.
   */
  @Test
  public void shouldReturnZeroForGetDegreeForTheEmptyPolynomial() {
    emptyPolynomial = new PolynomialImpl();
    assertEquals(0, emptyPolynomial.getDegree());
  }

  /**
   * test for get degree for the polynomial.
   */
  @Test
  public void shouldReturnDegreeForNonEmptyPolynomial() {
    polynomial = new PolynomialImpl("4x^3 +3x^1 -5");
    int actualOutput = polynomial.getDegree();
    int expectedOutput = 3;

    assertEquals(expectedOutput, actualOutput);
  }

  /**
   * test to return  zero as the coefficient for the empty polynomial when degree is given for it.
   */
  @Test
  public void shouldReturnCoefficientForEmptyPolynomial() {

    emptyPolynomial = new PolynomialImpl();
    assertEquals(0, emptyPolynomial.getCoefficient(1));
  }

  /**
   * test to return zero as coefficient when the polynomial does not have the coefficient for the
   * given degree.
   */
  @Test
  public void shouldReturnZeroForNonExistingCoefficientInANonEmptyPolynomial() {
    polynomial = new PolynomialImpl("4x^3 +3x^1 -5");
    assertEquals(0, polynomial.getCoefficient(2));
    Polynomial polynomial2 = new PolynomialImpl();
    polynomial2.addTerm(9, 51);
    assertEquals("9x^51", polynomial2.toString());
  }

  /**
   * test to return the correct coefficient for non empty polynomial for a given degree.
   */

  @Test
  public void shouldReturnCoefficientForANonEmptyPolynomial() {
    polynomial = new PolynomialImpl("4x^4 +7x^3 -5");
    assertEquals(7, polynomial.getCoefficient(3));
    // should return constant for passing 0 as degree
    assertEquals(-5, polynomial.getCoefficient(0));
  }

  /**
   * test to evaluate and return the double value for the given polynomial.
   */
  @Test
  public void shouldReturnExpectedValueForEvaluateOnPolynomial() {

    polynomial = new PolynomialImpl("4x^3 +3x^1 -5");
    double actualOutput = polynomial.evaluate(1.01);
    double expectedOutput = 2.151204000000001;
    assertEquals(expectedOutput, actualOutput,10);

    Polynomial polynomial2 = new PolynomialImpl("4x^3 +3x^1 -5");
    double actualOutput2 = polynomial2.evaluate(1.0);
    assertEquals(3, actualOutput2, 2);
  }

  /**
   * test to evaluate and return zero for empty polynomial.
   */
  @Test
  public void shouldReturnZeroOnEvaluateOfEmptyPolynomial() {
    emptyPolynomial = new PolynomialImpl();
    assertEquals(0.0, emptyPolynomial.evaluate(2.5), 2);
  }

  /**
   * test for adding new polynomial object to current polynomial object.
   */
  @Test
  public void shouldGiveNewPolynomialByAddingNewPolynomial() {
    polynomial = new PolynomialImpl("4x^3 +3x^1 -5");
    Polynomial p = new PolynomialImpl("2x^3 -1");
    String expectedOutput = "6x^3+3x^1-6";

    String actualOutput = polynomial.add(p).toString();

    assertEquals(expectedOutput, actualOutput);
    //original polynomial is not mutated.
    assertEquals("4x^3+3x^1-5", polynomial.toString());
    // new polynomial is not mutated.
    assertEquals("2x^3-1", p.toString());
  }

  /**
   * test for adding new polynomial on an empty polynomial object.
   */
  @Test
  public void shouldGiveNonEmptyPolynomialWhenAddingNewPolynomial() {
    emptyPolynomial = new PolynomialImpl();
    Polynomial p = new PolynomialImpl("x^52");
    String expectedOutput = "1x^52";

    String actualOutput = emptyPolynomial.add(p).toString();

    assertEquals(expectedOutput, actualOutput);
    //original polynomial is not mutated.
    assertEquals("0", emptyPolynomial.toString());
    // new polynomial is not mutated.
    assertEquals("x^52", p.toString());
  }

  /**
   * test for adding empty polynomial to a non empty polynomial.
   */
  @Test
  public void shouldReturnSamePolynomialWhenAddingEmptyPolynomial() {
    Polynomial p = new PolynomialImpl();
    polynomial = new PolynomialImpl("+3x^4 -2x^5 -5 -2x^4 +11x^1");
    String expectedOutput = "-2x^5+1x^4+11x^1-5";

    String actualOutput = polynomial.add(p).toString();

    assertEquals(expectedOutput, actualOutput);
    //original polynomial is not mutated.
    assertEquals("-2x^5+1x^4+11x^1-5", polynomial.toString());
    // new polynomial is not mutated.
    assertEquals("0", p.toString());
  }

  /**
   * test for adding new polynomial to an empty polynomial.
   */

  @Test
  public void shouldReturnValidSum() {
    emptyPolynomial = new PolynomialImpl();
    polynomial = new PolynomialImpl("1890x^188");
    Polynomial sum = emptyPolynomial.add(polynomial);
    assertEquals("1890x^188", sum.toString());

  }

  /**
   * test for multiplying a new polynomial with empty polynomial.
   */
  @Test
  public void shouldReturnZeroOnMultiplyForEmptyPolynomial() {
    emptyPolynomial = new PolynomialImpl();
    Polynomial p = new PolynomialImpl("4x^3");

    assertEquals("0", emptyPolynomial.multiply(p).toString());
  }

  /**
   * test for multiplying non empty polynomials.
   */
  @Test
  public void shouldReturnNonEmptyPolynomial() {
    Polynomial p = new PolynomialImpl("4x^3");
    polynomial = new PolynomialImpl("4x^3 +3x^1 -5");
    polynomial.addTerm(2321,32432);
    polynomial.addTerm(34,23);
    polynomial.addTerm(43,3456);
    polynomial.addTerm(55,85);
    polynomial.addTerm(55,0);
    polynomial.addTerm(0,1);

    assertEquals("9284x^32435+172x^3459" +
            "+220x^88+136x^26+16x^6+12x^4+200x^3", polynomial.multiply(p).toString());
    //original polynomial is not mutated.
    assertEquals("2321x^32432+43x^3456" +
            "+55x^85+34x^23+4x^3+3x^1+50", polynomial.toString());
    // new polynomial is not mutated.
    assertEquals("4x^3", p.toString());

    p = new PolynomialImpl("4x^3 -4x^3");
    assertEquals("0", polynomial.multiply(p).toString());
  }

  /**
   * test for multiplying two empty polynomials.
   */
  @Test
  public void shouldReturnZero() {
    Polynomial p = new PolynomialImpl("+4x^2");
    emptyPolynomial = new PolynomialImpl();
    assertEquals("0", emptyPolynomial.multiply(p).toString());
  }

  /**
   * test for first derivative for a non empty polynomial.
   */
  @Test
  public void shouldReturnDerivativeForNonEmptyPolynomial() {
    polynomial = new PolynomialImpl("4x^2 +1x^1");
    emptyPolynomial = new PolynomialImpl();
    String actualOutput = polynomial.derivative().toString();
    String expectedOutput = "8x^1+1";

    assertTrue(polynomial.equals(polynomial));

    assertEquals(expectedOutput, actualOutput);

    // should return zero since the polynomial is a constant.
    Polynomial p = new PolynomialImpl("5");
    assertEquals("0", p.derivative().toString());

    // should return zero since the polynomial is empty.
    assertEquals("0", emptyPolynomial.derivative().toString());
  }

  /**
   * test to check validation on a given string for derivation.
   */

  @Test(expected = IllegalArgumentException.class)
  public void shouldReturnInvalidEquationError() {
    Polynomial p = new PolynomialImpl("-260x^1 -90x^-13 -1164x^1 -1756x^62");
  }

  /**
   * test to check if two polynomials are equal.
   */
  @Test
  public void shouldReturnTrueForSamePolynomials() {
    polynomial = new PolynomialImpl("4x^3 +3x^1 -5");
    Polynomial polynomial2 = new PolynomialImpl("4x^3 +3x^1 -5");
    assertTrue(polynomial.equals(polynomial2));
  }

  @Test
  public void shouldReturnTrueForTwoPolynomials() {
    polynomial = new PolynomialImpl("4x^3 +3x^1 -5");
    Polynomial polynomial2 = new PolynomialImpl("4x^3 +3x^1 -5x^0");
    assertTrue(polynomial.equals(polynomial2));
  }

  @Test
  public void addTerm() {
    Polynomial polynomial = new PolynomialImpl();
    polynomial.addTerm(10, 10);
    polynomial.addTerm(10, 9);
    polynomial.addTerm(10, 8);
    polynomial.addTerm(100, 7);
    polynomial.addTerm(10, 6);
    polynomial.addTerm(10, 544);
    polynomial.addTerm(10, 4444);
    polynomial.addTerm(10, 32423);
    polynomial.addTerm(10, 2222);
    polynomial.addTerm(10, 1111);
    polynomial.addTerm(10, 0);
    assertEquals(100,polynomial.getCoefficient(7));

  }

  /**
   * RANDOM TEST.
   */

  @Test
  public void test1() {
    Polynomial p1 = new PolynomialImpl("9x^994 +14x^778 +10x^692 ");
    Polynomial p = new PolynomialImpl();
    Polynomial sum = p1.add(p);
    assertTrue(p1.equals(sum));

    p = new PolynomialImpl("x^6 -2x^3");
    assertFalse(p.equals(sum));
  }

  @Test
  public void testEvaluate() {
    Polynomial p1 = new PolynomialImpl("9x^994 +14x^778 +10x^692 +9x^587 +10x^439 +19x^355");

    assertEquals(224239.27373888055,p1.evaluate(1.01),6);
  }

  @Test
  public void testAdd() {
    polynomial = new PolynomialImpl();
    polynomial.addTerm(-98, 194);
    polynomial.addTerm(-35, 189);
    System.out.println(polynomial.toString());
    Polynomial p = new PolynomialImpl("-56x^194 -81x^189 +0x^1");

    Polynomial sum = polynomial.add(p);
    assertEquals("-154x^194-116x^189", sum.toString());
  }


  @Test
  public void test() {
    polynomial = new PolynomialImpl();
    polynomial.addTerm(0,32);
    polynomial.addTerm(-260,19);
    polynomial.addTerm(-14,13);
    polynomial.addTerm(-164,11);
    polynomial.addTerm(156,62);
    polynomial.addTerm(-160,31);
    polynomial.addTerm(47,29);
    polynomial.addTerm(-8,1);
    polynomial.addTerm(1,0);
    polynomial.addTerm(2,0);
    polynomial.addTerm(-3,0);

    Polynomial p = new PolynomialImpl();
    p.addTerm(260,19);
    p.addTerm(14,13);
    p.addTerm(164,11);
    p.addTerm(-156,62);
    p.addTerm(160,31);

    Polynomial derived = p.add(polynomial);
    assertEquals("1363x^28-8",derived.derivative().toString());

  }




}
